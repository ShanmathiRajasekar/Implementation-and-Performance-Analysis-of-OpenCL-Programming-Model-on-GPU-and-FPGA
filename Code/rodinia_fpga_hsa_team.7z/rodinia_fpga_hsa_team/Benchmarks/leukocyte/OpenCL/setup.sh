export XILINX_OPENCL=/home/shuowang/workspace/SDA_examples_2016.1/kernel_global/prj_hw_7v3_1ddr/pkg/pcie
export LD_LIBRARY_PATH=$XILINX_OPENCL/runtime/lib/x86_64:$LD_LIBRARY_PATH
export XCL_PLATFORM=xilinx_adm-pcie-7v3_1ddr_3_0
